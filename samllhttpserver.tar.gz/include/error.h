/*
 * error.h
 *
 * Functio protype handling errors.
 *
 */

 #ifndef ERROR_H
 #define ERROR_H

void error(char *msg);

 #endif
