/*
 *
 * function prototype. the impl should setup signal handler for SIGINT
 * and SIGCHLD.
 */
#ifndef SIGNAL_HANDLER_H
#define SIGNAL_HANDLER_H

int setup_signal_handlers();

#endif
